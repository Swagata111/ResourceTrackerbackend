package com.capgemini.tracker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
@Autowired
private EmployeeRepository repo;

public EmployeePojo create(int employeeId, String employeeName, String localGrade, String grade, String mode,
		String cloudJoiningDate, String joiningDate, String officeLocation, String location, String seat,
		String email, String benchStartDate, String level3EngagementRole, String gP, String currentAccount,
		String projectCode, String projectName, String projectStartDate, String projectEndDate,
		String primarySkill)
{
	return repo.save(new EmployeePojo(employeeId, employeeName, localGrade, grade, mode, cloudJoiningDate, joiningDate, officeLocation, location, seat, email, benchStartDate, level3EngagementRole, gP, currentAccount, projectCode, projectName, projectStartDate, projectEndDate, primarySkill));
}

public List<EmployeePojo> findAllEmployee()
	{
      return repo.findAll();
    }

	public EmployeePojo findByemployeeId(int employeeId)
	{
     return repo.findByemployeeId(employeeId);
   }
	
	   void delete(EmployeePojo emp)
	   {
		   repo.delete(emp);
	   }


}
