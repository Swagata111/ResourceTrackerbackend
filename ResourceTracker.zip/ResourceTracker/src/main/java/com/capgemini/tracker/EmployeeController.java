package com.capgemini.tracker;

import java.util.Map;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin

public class EmployeeController 
{
	@Autowired
	private EmployeeService empService;	
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	   public void insert(Model model,@RequestBody EmployeePojo employee,BindingResult result,Map<String,Object> model1) throws Exception				   
	   {
		System.out.println("into it");

     if (result.hasErrors()) {
         throw new ValidationException();
     }
 		empService.create(employee.employeeId, employee.employeeName, employee.localGrade, 
 				employee.grade,
 				employee. mode, employee.cloudJoiningDate, employee.joiningDate, 
 				employee.officeLocation, 
 				employee.location,employee.seat, employee.email, employee.benchStartDate, 
 				employee.level3EngagementRole, 
 				employee.gP, employee.currentAccount, employee.projectCode, employee.projectName, 
 				employee.projectStartDate, 
 			employee.projectEndDate, employee.primarySkill);	
 		System.out.println("inserted");
 		
    }
	
    @RequestMapping(method=RequestMethod.PUT, value="/update/{id}")
    public EmployeePojo update(@PathVariable int employeeId, @RequestBody EmployeePojo employee) 
    {
    	EmployeePojo employee1 = empService.findByemployeeId(employeeId);
    	if(employee.getCurrentAccount()!=null)
    		employee.setCurrentAccount(employee.getCurrentAccount());
    	
    	if(employee.getGrade()!=null)
    		employee.setGrade(employee.getGrade());
    	
    	if(employee.getLocalGrade()!=null)
    		employee.setLocalGrade(employee.getLocalGrade());
    	
    	if(employee.getLocation()!=null)
    		employee.setLocation(employee.getLocation());
    	
    	if(employee.getOfficeLocation()!=null)
    		employee.setOfficeLocation(employee.getOfficeLocation());
    	
    	if(employee.getgP()!=null)
    		employee.setgP(employee.getgP());
    	
    	if(employee.getLevel3EngagementRole()!=null)
    		employee.setLevel3EngagementRole(employee.getLevel3EngagementRole());
    	
    	if(employee.getPrimarySkill()!=null)
    		employee.setPrimarySkill(employee.getPrimarySkill());
    	
    	
    	if(employee.getProjectCode()!=null)
    		employee.setProjectCode(employee.getProjectCode());
    	
    	if(employee.getProjectEndDate()!=null)
    		employee.setProjectEndDate(employee.getProjectEndDate());
    	
    	if(employee.getProjectName()!=null)
    		employee.setProjectName(employee.getProjectName());
    	
    	if(employee.getProjectStartDate()!=null)
    		employee.setProjectStartDate(employee.getProjectStartDate());
    	
    	if(employee.getSeat()!=null)
    		employee.setSeat(employee.getSeat());
    	empService.create(employee1.employeeId, employee1.employeeName, employee1.localGrade, 
 				employee1.grade,
 				employee1. mode, employee1.cloudJoiningDate, employee1.joiningDate, 
 				employee1.officeLocation, 
 				employee1.location,employee1.seat, employee1.email, employee1.benchStartDate, 
 				employee1.level3EngagementRole, 
 				employee1.gP, employee1.currentAccount, employee1.projectCode, employee1.projectName, 
 				employee1.projectStartDate, 
 			employee1.projectEndDate, employee1.primarySkill);		
   
    	return employee;
    	
    	}
	
    @RequestMapping(method=RequestMethod.DELETE, value="/delete/{id}")
    public String delete(@PathVariable int employeeId)
    {
    	EmployeePojo employee1 = empService.findByemployeeId(employeeId);
    	empService.delete(employee1);
		return null;
    	
    }
    	

}
